# RFBDoSBC

This package explores the distinction between real and combinatorial jets in order to determine the best practices in reducing the background contribution to jet measurements.